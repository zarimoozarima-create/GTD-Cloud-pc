# GTD Cloud PC

Bu `index.html` — GTD Cloud PC saytining mobilga mos frontend prototipi.

## Ishga tushirish
`index.html` faylini brauzerda oching yoki statik hostingga joylang.

## Muhim
Bu prototip haqiqiy Windows 10 yoki RTX serverini ishga tushirmaydi. Buning uchun alohida Windows VM/GPU server, masofaviy desktop gateway (masalan, RDP/VNC asosidagi xavfsiz gateway), autentifikatsiya, sessiya boshqaruvi va avtomatik tozalash backendi kerak. Server provayderi va xarajatlari belgilanmaguncha “3 soat bepul” yoki RTX mavjud deb va’da berilmaydi.
